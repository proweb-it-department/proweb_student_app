part of 'downloads_exclusive_product_video_bloc.dart';

@freezed
class DownloadsExclusiveProductVideoEvent with _$DownloadsExclusiveProductVideoEvent {
  const factory DownloadsExclusiveProductVideoEvent.started() = _Started;
}