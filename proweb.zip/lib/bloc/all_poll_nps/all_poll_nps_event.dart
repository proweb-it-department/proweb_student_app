part of 'all_poll_nps_bloc.dart';

@freezed
class AllPollNpsEvent with _$AllPollNpsEvent {
  const factory AllPollNpsEvent.started() = _Started;
}