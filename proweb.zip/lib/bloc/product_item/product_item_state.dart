part of 'product_item_bloc.dart';

@freezed
class ProductItemState with _$ProductItemState {
  const factory ProductItemState.initial() = _Initial;
}
