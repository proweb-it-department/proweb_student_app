part of 'branch_room_holiday_bloc.dart';

@freezed
class BranchRoomHolidayEvent with _$BranchRoomHolidayEvent {
  const factory BranchRoomHolidayEvent.started() = _Started;
}