part of 'nps_poll_bloc.dart';

@freezed
class NpsPollEvent with _$NpsPollEvent {
  const factory NpsPollEvent.started() = _Started;
}