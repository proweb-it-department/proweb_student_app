part of 'downloads_groups_videos_bloc.dart';

@freezed
class DownloadsGroupsVideosEvent with _$DownloadsGroupsVideosEvent {
  const factory DownloadsGroupsVideosEvent.started() = _Started;
}