part of 'offer_path_bloc.dart';

@freezed
class OfferPathEvent with _$OfferPathEvent {
  const factory OfferPathEvent.started() = _Started;
}