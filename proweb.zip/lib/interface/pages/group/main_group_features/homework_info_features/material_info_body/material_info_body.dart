import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:proweb_student_app/bloc/material_group/material_group_bloc.dart';
import 'package:proweb_student_app/interface/components/md3_circule_indicator/md3_circule_indicator.dart';
import 'package:proweb_student_app/interface/components/md3_refresh_indicator/md3_refresh_indicator.dart';
import 'package:proweb_student_app/interface/components/no_data/no_data.dart';
import 'package:proweb_student_app/interface/pages/group/main_group_features/homework_info_features/material_info_item/material_info_item.dart';
import 'package:proweb_student_app/models/group_detail/group_detail.dart';
import 'package:proweb_student_app/models/material_list_group/material_list_group.dart';
import 'package:proweb_student_app/models/response_laze_list.dart';
import 'package:proweb_student_app/utils/gi/injection_container.dart';
import 'package:very_good_infinite_list/very_good_infinite_list.dart';

class MaterialInfoBody extends StatefulWidget {
  final ResponseLazeList<MaterialListGroup> data;
  final GroupDetail group;
  const MaterialInfoBody({super.key, required this.data, required this.group});

  @override
  State<MaterialInfoBody> createState() => _MaterialInfoBodyState();
}

class _MaterialInfoBodyState extends State<MaterialInfoBody> {
  var _isLoading = false;

  void _fetchData(BuildContext context) async {
    setState(() {
      _isLoading = true;
    });

    final bloc = context.read<MaterialGroupBloc>();
    bloc.add(
      MaterialGroupEvent.started(
        groupId: widget.group.id!,
        limit: LimitRequest.homework,
        offset: widget.data.list.length,
      ),
    );
    await bloc.stream.first;
    if (!mounted) {
      return;
    }
    setState(() {
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewPadding.bottom;
    return Md3RefreshIndicator(
      onRefresh: () async {
        final groupId = widget.group.id;
        if (groupId != null) {
          final bloc = context.read<MaterialGroupBloc>();
          bloc.add(
            MaterialGroupEvent.started(
              groupId: groupId,
              limit: LimitRequest.homework,
              offset: 0,
            ),
          );
          await bloc.stream.first;
        }
      },
      child: InfiniteList(
        isLoading: _isLoading,
        centerLoading: true,
        emptyBuilder: (context) {
          return NoData(
            text: 'group_homework.not_found_material'.tr(),
            icon: Icons.file_present,
          );
        },
        hasReachedMax: widget.data.count == widget.data.list.length,
        onFetchData: () => _fetchData(context),
        loadingBuilder: (context) => Center(
          child: Container(
            width: 50,
            height: 50,
            padding: EdgeInsets.all(10),
            child: Md3CirculeIndicator(),
          ),
        ),
        padding: EdgeInsets.only(left: 10, right: 10, bottom: bottom + 10),
        itemCount: widget.data.list.length,
        itemBuilder: (context, index) {
          final item = widget.data.list[index];
          return MaterialInfoItem(group: widget.group, item: item);
        },
        separatorBuilder: (context, index) {
          return SizedBox(height: 10);
        },
      ),
    );
  }
}
