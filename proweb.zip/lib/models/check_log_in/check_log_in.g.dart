// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'check_log_in.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_CheckLogIn _$CheckLogInFromJson(Map<String, dynamic> json) => _CheckLogIn(
  hasUsablePassword: json['has_usable_password'] as bool,
  sended: json['sended'],
);

Map<String, dynamic> _$CheckLogInToJson(_CheckLogIn instance) =>
    <String, dynamic>{
      'has_usable_password': instance.hasUsablePassword,
      'sended': instance.sended,
    };
