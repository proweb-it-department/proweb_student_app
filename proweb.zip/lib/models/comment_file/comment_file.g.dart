// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'comment_file.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_CommentFile _$CommentFileFromJson(Map<String, dynamic> json) =>
    _CommentFile(id: (json['id'] as num?)?.toInt());

Map<String, dynamic> _$CommentFileToJson(_CommentFile instance) =>
    <String, dynamic>{'id': instance.id};
